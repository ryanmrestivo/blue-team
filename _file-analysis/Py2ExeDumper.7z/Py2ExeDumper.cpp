/*
Py2ExeDumper is a tool to extract a py2exe generated executable file.
It extracts the embedded python script and the library.zip

Developed by ExtremeCoders
E-mail : extremecoders@hotmail.com
Licensed under MIT License
Feel Free to modify the source code as per your needs

Updated on : 01-May-2015
*/

#include <windows.h>
#include <stdio.h>

FILE *fPtr;
char *fileName;

// Check if the file starts with a valid MZ signature
BOOL validateFile()
{
	printf("[*] Validating file\n");
	fPtr = fopen(fileName, "rb");

	if(!fPtr)
	{
		printf("[*] Failed to open %s\n", fileName);
		return FALSE;
	}
	
	fseek(fPtr, 0, SEEK_SET);

	char magic[2];
	fread(magic, 2, 1, fPtr);

	if(magic[0] != 'M' || magic[1] != 'Z')
	{
		printf("[*] Invalid PE File!\n");
		fclose(fPtr);
		return FALSE;
	}
	printf("[*] File validated successfully\n");
	return TRUE;
}

// Extract PYTHONSCRIPT which is stored as a resource
BOOL extractPythonScript()
{
	printf("[*] Extracting PYTHONSCRIPT\n");
	HMODULE hMod = LoadLibraryEx(fileName, NULL, LOAD_LIBRARY_AS_DATAFILE);
	HRSRC hRes = FindResource(hMod,MAKEINTRESOURCE(1),"PYTHONSCRIPT");
	
	if(hRes)
	{
		DWORD size = SizeofResource(hMod,hRes);
		HGLOBAL hGbl = LoadResource(hMod,hRes);
		char *resPtr = (char*)LockResource(hGbl);
		FILE *out = fopen("PYTHONSCRIPT","wb");
		fwrite(resPtr, size, 1, out);
		fclose(out);
		FreeResource(hGbl);
		printf("[*] PYTHONSCRIPT extracted successfully\n");
	}
	else
		printf("[*] PYTHONSCRIPT does not exist. Probably this is not a py2exe generated file\n");
	FreeLibrary(hMod);
	return hRes != NULL;
}

// Extract library.zip which is actually an overlay
void extractLibrary()
{
	fseek(fPtr, 0, SEEK_SET);
	IMAGE_DOS_HEADER image_dos_header;
	fread(&image_dos_header, sizeof(IMAGE_DOS_HEADER), 1, fPtr);

	IMAGE_NT_HEADERS image_nt_headers;
	fseek(fPtr,image_dos_header.e_lfanew, SEEK_SET);
	fread(&image_nt_headers, sizeof(IMAGE_NT_HEADERS), 1, fPtr);
	
	WORD numberOfSections = image_nt_headers.FileHeader.NumberOfSections;
	DWORD pointerToRawData = 0;
	DWORD sizeOfRawData = 0;

	IMAGE_SECTION_HEADER image_section_header;
	for(WORD i = 0; i < numberOfSections; i++)
	{
		memset(&image_section_header, 0, sizeof(IMAGE_SECTION_HEADER));
		fread(&image_section_header, sizeof(IMAGE_SECTION_HEADER), 1, fPtr);
		if(image_section_header.PointerToRawData > pointerToRawData)
		{
			pointerToRawData = image_section_header.PointerToRawData;
			sizeOfRawData = image_section_header.SizeOfRawData;
		}
	}
	
	fseek(fPtr, 0, SEEK_END);
	DWORD fileSize = ftell(fPtr);
	DWORD zipFileSize = fileSize - pointerToRawData - sizeOfRawData;

	if(zipFileSize <= 0)
	{
		printf("[*] Library.zip not found\n");
		fclose(fPtr);
		return;
	}
	
	fseek(fPtr, pointerToRawData + sizeOfRawData, SEEK_SET);
	char *buf = (char*) VirtualAlloc(NULL, zipFileSize, MEM_COMMIT, PAGE_READWRITE);
	
	if(!buf)
	{
		printf("[*] Failed to allocate memory for library.zip\n");
		fclose(fPtr);
		return;
	}	
	fread(buf, zipFileSize, 1, fPtr);
	
	if(buf[0] != 'P' || buf[1] != 'K' || buf[2] != '\x03' || buf[3] != '\x04')
	{
		printf("[*] Warning : library.zip header mismatch (not a zip file)\n");
		fclose(fPtr);
		VirtualFree(buf, zipFileSize, MEM_RELEASE);
		return;
	}
	
	printf("[*] Dumping library.zip\n");
	FILE *out = fopen("library.zip","wb");
	if(!out)
	{
		printf("[*] Failed to create file library.zip\n");
		fclose(fPtr);
		VirtualFree(buf, zipFileSize, MEM_RELEASE);
		return;
	}
	
	fwrite(buf, zipFileSize, 1, out);
	fclose(out);
	fclose(fPtr);
	VirtualFree(buf, zipFileSize, MEM_RELEASE);
	printf("[*] Successfully dumped library.zip\n");
}

int main(int argc, char *argv[])
{
	if(argc < 2)
	{
		printf("Py2ExeDumper is a tool to extract a py2exe generated executable\n");
		printf("It dumps the embedded pythonscript and library.zip\n");
		printf("Developed By ExtremeCoders [ extremecoders@hotmail.com ]\n");		
		printf("\nUsage : py2exedumper <exefilename>\n");
		Sleep(7000);
		return 1;
	}
	fileName = argv[1];

	if(validateFile())
		if(extractPythonScript())
			extractLibrary();
	Sleep(3000);
	return 0;	
}