How to use
----------------------------

You can start Py2ExeDumper in 2 ways - 

1. You can open command prompt and run the file.

C:\>py2exeDumper <exefilename>

2. You can drag and drop the exe file you wish to extract on Py2ExeDumper.


Other useful information
----------------------------

If your exe file is packed in any way such as by upx (http://upx.sourceforge.net/),
then please unpack the file first before using this tool.


Changelog
----------------------------

01-May-2015
 . Improved security, will load the exe as a datafile.
 . Improved memory allocation for library.zip

01-Mar-2014
 . First Release


Developed by ExtremeCoders
email: extremecoders@hotmail.com
Licensed under MIT License
Feel Free to modify the source code as per your needs