registry = None
config = type(None)
